#!/bin/bash
echo "Cleaning up old application files..."
rm -rf /home/ec2-user/node-app/*
