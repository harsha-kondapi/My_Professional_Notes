# My Node.js App
This is a sample Node.js application with a CI/CD pipeline using AWS CodePipeline, CodeBuild, and CodeDeploy.