#!/bin/bash
echo "Installing Node.js dependencies..."
cd /home/ec2-user/node-app
npm install
