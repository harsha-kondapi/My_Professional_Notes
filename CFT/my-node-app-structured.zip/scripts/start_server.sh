#!/bin/bash
echo "Starting Node.js application..."
cd /home/ec2-user/node-app
npm start &
